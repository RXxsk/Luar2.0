void main()
{
	SetOutput(Sample());
}
